package dev.mvc.emcate;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import dev.mvc.emotions.EmotionsProcInter;
import dev.mvc.emotions.EmotionsVO;
import dev.mvc.member.MemberProcInter;
import dev.mvc.tool.Tool;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/emcate")
public class EmcateCont {
  @Autowired
  @Qualifier("dev.mvc.emcate.EmcateProc")
  private EmcateProcInter emcateProc;
  
  @Autowired
  @Qualifier("dev.mvc.emotions.EmotionsProc")
  private EmotionsProcInter emotionsProc;

  /** 페이지당 출력할 레코드 갯수, nowPage는 1부터 시작 */
  public int record_per_page = 10;

  /** 블럭당 페이지 수, 하나의 블럭은 10개의 페이지로 구성됨 */
  public int page_per_block = 10;

  /** 페이징 목록 주소 */
  private String list_file_name = "/emcate/list_search";

  @Autowired
  @Qualifier("dev.mvc.member.MemberProc") // @Service("dev.mvc.member.MemberProc")
  private MemberProcInter memberProc;

//  @Autowired
//  @Qualifier("dev.mvc.emcate.EmcateProc2023")
//  private EmcateProcInter emcateProc;

//  @Autowired
//  @Qualifier("dev.mvc.emcate.EmcateProc")
//  private EmcateProcInter emcateProc;

  public EmcateCont() {
    System.out.println("-> EmcateCont created.");
  }

//  @GetMapping(value="/create") // http://localhost:9092/emcate/create
//  @ResponseBody // html 파일 내용임.
//  public String create() {
//    return "<h2>Create test</h2>";
//  }

//  @GetMapping(value="/create") // http://localhost:9092/emcate/create
//  public String create() {
//    return "/emcate/create"; // /templates/emcate/create.html
//  }

  /**
   * 등록 폼
   * 
   * @param model
   * @return
   */
  // http://localhost:9092/emcate/create/ X
  // http://localhost:9092/emcate/create
  @GetMapping(value = "/create")
  public String create(Model model) {
    EmcateVO emcateVO = new EmcateVO();
    model.addAttribute("emcateVO", emcateVO);

    emcateVO.setGenre("분류");
    emcateVO.setName("카테고리 이름을 입력하세요."); // Form으로 초기값을 전달
    return "/emcate/create"; // /templates/emcate/create.html
  }

// - 유형 1 (권장): 옵션 모두 표시
//  @PostMapping(value="/create") // http://localhost:9092/emcate/create
//  public String create(Model model, @Valid @ModelAttribute("btcemcateVO") BtcEmcateVO btcemcateVO, BindingResult bindingresult) {
//
// - 유형 2: 코드 생략형
// @PostMapping(value="/create") // http://localhost:9092/emcate/create
// public String create(Model model, @Valid EmcateVO emcateVO, BindingResult bindingResult) {
  /**
   * 등록 처리, http://localhost:9092/emcate/create
   * 
   * @param model         Controller -> Thymeleaf HTML로 데이터 전송에 사용
   * @param emcateVO        Form 태그 값 -> 검증 -> emcateVO 자동 저장, request.getParameter()
   *                      자동 실행
   * @param bindingResult 폼에 에러가 있는지 검사 지원
   * @return
   */
  @PostMapping(value = "/create")
  public String create(Model model, @Valid @ModelAttribute("emcateVO") EmcateVO emcateVO, BindingResult bindingResult) {
//    System.out.println("-> create post.");
    if (bindingResult.hasErrors() == true) { // 에러가 있으면 폼으로 돌아갈 것.
//      System.out.println("-> ERROR 발생");
      // model.addAttribute("emcateVO", emcateVO);
      return "/emcate/create"; // /templates/emcate/create.html
    }

//    System.out.println(emcateVO.getName());
//    System.out.println(emcateVO.getSeqno());
//    System.out.println(emcateVO.getVisible());
    
    emcateVO.setGenre(emcateVO.getGenre().trim());
    emcateVO.setName(emcateVO.getName().trim());
    
    int cnt = this.emcateProc.create(emcateVO);
    System.out.println("-> cnt: " + cnt);

    if (cnt == 1) {
      // model.addAttribute("code", "create_success");
      // model.addAttribute("name", emcateVO.getName());

      // return "redirect:/emcate/list_all"; // @GetMapping(value="/list_all")
      return "redirect:/emcate/list_search"; // @GetMapping(value="/list_all")
    } else {
      model.addAttribute("code", "create_fail");
    }

    model.addAttribute("cnt", cnt);

    return "/emcate/msg"; // /templates/emcate/msg.html
  }

  /**
   * 등록 폼 및 목록
   * 
   * @param model
   * @return
   */
  // http://localhost:9092/emcate/list_all
  @GetMapping(value = "/list_all")
  public String list_all(Model model) {
    EmcateVO emcateVO = new EmcateVO();
    // emcateVO.setGenre("분류");
    // emcateVO.setName("카테고리 이름을 입력하세요."); // Form으로 초기값을 전달

    // 카테고리 그룹 목록
    ArrayList<String> list_genre = this.emcateProc.genreset();
    emcateVO.setGenre(String.join("/", list_genre));

    model.addAttribute("emcateVO", emcateVO);

    ArrayList<EmcateVO> list = this.emcateProc.list_all();
    model.addAttribute("list", list);

//    ArrayList<EmcateVO> menu = this.emcateProc.list_all_emcategrp_y();
//    model.addAttribute("menu", menu);

    ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
    model.addAttribute("menu", menu);

    return "/emcate/list_all"; // /templates/emcate/list_all.html
  }

  /**
   * 조회 http://localhost:9092/emcate/read/1
   */
  @GetMapping(value = "/read/{emcateno}")
  public String read(Model model, @PathVariable("emcateno") Integer emcateno,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page) {
    EmcateVO emcateVO = this.emcateProc.read(emcateno);
    model.addAttribute("emcateVO", emcateVO);

    // ArrayList<EmcateVO> list = this.emcateProc.list_all();
    // ArrayList<EmcateVO> list = this.emcateProc.list_search(word);
    ArrayList<EmcateVO> list = this.emcateProc.list_search_paging(word, now_page, this.record_per_page);
    model.addAttribute("list", list);

//   ArrayList<EmcateVO> menu = this.emcateProc.list_all_emcategrp_y();
//   model.addAttribute("menu", menu);

    ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
    model.addAttribute("menu", menu);

    model.addAttribute("word", word);

    // --------------------------------------------------------------------------------------
    // 페이지 번호 목록 생성
    // --------------------------------------------------------------------------------------
    int search_count = this.emcateProc.list_search_count(word);
    String paging = this.emcateProc.pagingBox(now_page, word, this.list_file_name, search_count, this.record_per_page,
        this.page_per_block);
    model.addAttribute("paging", paging);
    model.addAttribute("now_page", now_page);

    // 일련 변호 생성: 레코드 갯수 - ((현재 페이지수 -1) * 페이지당 레코드 수)
    int no = search_count - ((now_page - 1) * this.record_per_page);
    model.addAttribute("no", no);
    // --------------------------------------------------------------------------------------

    return "/emcate/read";
  }

  /**
   * 수정폼 http://localhost:9092/emcate/update/1
   */
  @GetMapping(value = "/update/{emcateno}")
  public String update(HttpSession session, Model model, @PathVariable("emcateno") Integer emcateno,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page) {
    if (this.memberProc.isMemberAdmin(session)) {
      EmcateVO emcateVO = this.emcateProc.read(emcateno);
      model.addAttribute("emcateVO", emcateVO);

      // ArrayList<EmcateVO> list = this.emcateProc.list_all();
      ArrayList<EmcateVO> list = this.emcateProc.list_search_paging(word, now_page, this.record_per_page);
      model.addAttribute("list", list);

//     ArrayList<EmcateVO> menu = this.emcateProc.list_all_emcategrp_y();
//     model.addAttribute("menu", menu);

      ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
      model.addAttribute("menu", menu);

      // 카테고리 그룹 목록
      ArrayList<String> list_genre = this.emcateProc.genreset();
      model.addAttribute("list_genre", String.join("/", list_genre));

      model.addAttribute("word", word);

      // --------------------------------------------------------------------------------------
      // 페이지 번호 목록 생성
      // --------------------------------------------------------------------------------------
      int search_count = this.emcateProc.list_search_count(word);
      String paging = this.emcateProc.pagingBox(now_page, word, this.list_file_name, search_count, this.record_per_page,
          this.page_per_block);
      model.addAttribute("paging", paging);
      model.addAttribute("now_page", now_page);

      // 일련 변호 생성: 레코드 갯수 - ((현재 페이지수 -1) * 페이지당 레코드 수)
      int no = search_count - ((now_page - 1) * this.record_per_page);
      model.addAttribute("no", no);
      // --------------------------------------------------------------------------------------

      return "/emcate/update"; // templaes/emcate/update.html
    } else {
      return "redirect:/member/login_cookie_need"; // redirect
    }
  }

  /**
   * 수정 처리, http://localhost:9092/emcate/update
   * 
   * @param model         Controller -> Thymeleaf HTML로 데이터 전송에 사용
   * @param emcateVO        Form 태그 값 -> 검증 -> emcateVO 자동 저장, request.getParameter()
   *                      자동 실행
   * @param bindingResult 폼에 에러가 있는지 검사 지원
   * @return
   */
  @PostMapping(value = "/update")
  public String update(HttpSession session, Model model, 
      @Valid @ModelAttribute("emcateVO") EmcateVO emcateVO, BindingResult bindingResult,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page, RedirectAttributes ra) {
    if (this.memberProc.isMemberAdmin(session)) {
//    System.out.println("-> update post.");
    if (bindingResult.hasErrors() == true) { // 에러가 있으면 폼으로 돌아갈 것.
//      System.out.println("-> ERROR 발생");
      return "/emcate/update"; // /templates/emcate/update.html
    }

//    System.out.println(emcateVO.getName());
//    System.out.println(emcateVO.getSeqno());
//    System.out.println(emcateVO.getVisible());
    
    emcateVO.setGenre(emcateVO.getGenre().trim());
    emcateVO.setName(emcateVO.getName().trim());

    int cnt = this.emcateProc.update(emcateVO);
    System.out.println("-> cnt: " + cnt);

    if (cnt == 1) {
//      model.addAttribute("code", "update_success");
//      model.addAttribute("genre", emcateVO.getGenre());
//      model.addAttribute("name", emcateVO.getName());

      ra.addAttribute("word", word); // redirect로 데이터 전송
      ra.addAttribute("now_page", now_page); // redirect로 데이터 전송

      return "redirect:/emcate/update/" + emcateVO.getEmcateno(); // @GetMapping(value="/update/{emcateno}")
    } else {
      model.addAttribute("code", "update_fail");
    }

    model.addAttribute("cnt", cnt);

    // --------------------------------------------------------------------------------------
    // 페이지 번호 목록 생성
    // --------------------------------------------------------------------------------------
    int search_count = this.emcateProc.list_search_count(word);
    String paging = this.emcateProc.pagingBox(now_page, word, this.list_file_name, search_count, this.record_per_page,
        this.page_per_block);
    model.addAttribute("paging", paging);
    model.addAttribute("now_page", now_page);

    // 일련 변호 생성: 레코드 갯수 - ((현재 페이지수 -1) * 페이지당 레코드 수)
    int no = search_count - ((now_page - 1) * this.record_per_page);
    model.addAttribute("no", no);
    // --------------------------------------------------------------------------------------

    return "/emcate/msg"; // /templates/emcate/msg.html
    } else {
      return "redirect:/member/login_cookie_need";  // redirect
    }
    
  }

  /**
   * 삭제폼 http://localhost:9092/emcate/delete/1
   */
  @GetMapping(value = "/delete/{emcateno}")
  public String delete(HttpSession session, Model model, 
      @PathVariable("emcateno") Integer emcateno,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page) {
    if (this.memberProc.isMemberAdmin(session)) {
      EmcateVO emcateVO = this.emcateProc.read(emcateno);
      model.addAttribute("emcateVO", emcateVO);
      int cnt = this.emcateProc.cntcount(emcateno);

      // ArrayList<EmcateVO> list = this.emcateProc.list_all();
      ArrayList<EmcateVO> list = this.emcateProc.list_search_paging(word, now_page, this.record_per_page);
      model.addAttribute("list", list);

//     ArrayList<EmcateVO> menu = this.emcateProc.list_all_emcategrp_y();
//     model.addAttribute("menu", menu);

      ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
      model.addAttribute("menu", menu);
      
      model.addAttribute("cnt", cnt); // 콘텐츠 개수 추가
      model.addAttribute("word", word);
      model.addAttribute("now_page", now_page);

      // --------------------------------------------------------------------------------------
      // 페이지 번호 목록 생성
      // --------------------------------------------------------------------------------------
      int search_count = this.emcateProc.list_search_count(word);
      String paging = this.emcateProc.pagingBox(now_page, word, this.list_file_name, search_count, this.record_per_page,
          this.page_per_block);
      model.addAttribute("paging", paging);
      model.addAttribute("now_page", now_page);

      // 일련 변호 생성: 레코드 갯수 - ((현재 페이지수 -1) * 페이지당 레코드 수)
      int no = search_count - ((now_page - 1) * this.record_per_page);
      model.addAttribute("no", no);
      // --------------------------------------------------------------------------------------
      if (cnt == 0) {
        return "/emcate/delete"; // templaes/emcate/delete.html
      } else {
        // 콘텐츠가 있을 경우 emcate/list_all_delete.html로 이동
        ArrayList<EmotionsVO> emotionsList = emotionsProc.ListByEmcateNo(emcateno); // 해당 카테고리의 콘텐츠 리스트 불러오기
        model.addAttribute("emotionsList", emotionsList);
        model.addAttribute("cnt", cnt);
        model.addAttribute("word", word);
        model.addAttribute("now_page", now_page);
        return "/emcate/list_all_delete"; // emcate/list_all_delete.html로 이동
      }
    } else {
      return "redirect:/member/login_cookie_need";  // 관리자 권한 필요
    }
  }
  
  /**
   * 카테고리 및 관련 자료 삭제 처리
   * @param emcateno
   * @param redirectAttributes
   * @return
   */
  @PostMapping(value = "/delete_all_confirm")
  public String deleteAllEmcate(@RequestParam (name = "emcateno", defaultValue = "0") int emcateno,
                              RedirectAttributes redirectAttributes) {
    // 콘텐츠 삭제
    emotionsProc.DeleteByEmcateNo(emcateno);
    
    // 카테고리 삭제
    emcateProc.delete(emcateno);
    
    redirectAttributes.addFlashAttribute("msg", "카테고리와 관련된 모든 자료가 삭제되었습니다.");
    return "redirect:/emcate/list_search";
  }
  
  @GetMapping(value = "/delete")
  public String delete(Model model) {
    // 기본 삭제 폼
    return "/emcate/delete"; // emcate/delete.html로 이동
  }

  /**
   * 삭제 처리, http://localhost:9092/emcate/delete?emcateno=1
   * 
   * @param model         Controller -> Thymeleaf HTML로 데이터 전송에 사용
   * @param emcateVO        Form 태그 값 -> 검증 -> emcateVO 자동 저장, request.getParameter()
   *                      자동 실행
   * @param bindingResult 폼에 에러가 있는지 검사 지원
   * @return
   */
  @PostMapping(value = "/delete")
  public String delete_process(HttpSession session, Model model, 
      @RequestParam(name = "emcateno", defaultValue = "0") Integer emcateno,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page, 
      RedirectAttributes ra) {
    
    // 관리자 권한 확인
    if (this.memberProc.isMemberAdmin(session)) {
      System.out.println("-> delete_process");

      EmcateVO emcateVO = this.emcateProc.read(emcateno); // 삭제전에 삭제 결과를 출력할 레코드 조회
      model.addAttribute("emcateVO", emcateVO);
      
      // 카테고리에 속한 콘텐츠 개수 확인
      int cnt = this.emcateProc.delete(emcateno); // 해당 카테고리 내 콘텐츠 수
//      System.out.println("-> cnt: " + cnt);

      if (cnt == 0) {
        // 콘텐츠가 없으면 카테고리만 삭제
        int deleteCnt = this.emcateProc.delete(emcateno);
        System.out.println("-> deleteCnt: " + deleteCnt);
        
        if (deleteCnt == 1) {
          ra.addAttribute("word", word); // redirect로 데이터 전송
          
          // 마지막 페이지에서 모든 레코드가 삭제되면 페이지수를 1 감소 시켜야한다.
          int search_cnt = this.emcateProc.list_search_count(word);
          if (search_cnt % this.record_per_page == 0) {
            now_page = now_page - 1;
            if (now_page < 1) {
              now_page = 1; // 최소 시작 페이지
            }
          }
          
          ra.addAttribute("now_page", now_page); // redirect로 데이터 전송
          
          return "redirect:/emcate/list_search"; // 카테고리 목록 페이지로 redirect
        } else {
          model.addAttribute("code", "delete_fail");
          return "/emcate/msg"; // 실패 메시지 출력
        }
        
      } else {
        // 콘텐츠가 있을 경우 emcate/list_all_delete.html로 이동하여 확인 요청
        ArrayList<EmotionsVO> emotionsList = emotionsProc.ListByEmcateNo(emcateno); // 해당 카테고리의 콘텐츠 리스트 불러오기
        model.addAttribute("emotionsList", emotionsList);
        model.addAttribute("cnt", cnt);
        model.addAttribute("word", word);
        model.addAttribute("now_page", now_page);
        return "/emcate/list_all_delete"; // emcate/list_all_delete.html로 이동
      }
    } else {
      return "redirect:/member/login_cookie_need";  // // 권한 없을 때 로그인 페이지로 redirect
    }
  }

  /**
   * 우선 순위 높임, 10 등 -> 1 등, http://localhost:9092/emcate/update_seqno_forward/1
   * 
   * @param model Controller -> Thymeleaf HTML로 데이터 전송에 사용
   * @return
   */
  @GetMapping(value = "/update_seqno_forward/{emcateno}")
  public String update_seqno_forward(Model model, 
      @PathVariable("emcateno") Integer emcateno,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page, RedirectAttributes ra) {
    this.emcateProc.update_seqno_forward(emcateno);

    ra.addAttribute("word", word); // redirect로 데이터 전송
    ra.addAttribute("now_page", now_page); // redirect로 데이터 전송

    return "redirect:/emcate/list_search"; // @GetMapping(value="/list_search")
  }

  /**
   * 우선 순위 낮춤, 1 등 -> 10 등, http://localhost:9092/emcate/update_seqno_backward/1
   * 
   * @param model Controller -> Thymeleaf HTML로 데이터 전송에 사용
   * @return
   */
  @GetMapping(value = "/update_seqno_backward/{emcateno}")
  public String update_seqno_backward(Model model, @PathVariable("emcateno") Integer emcateno,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page, RedirectAttributes ra) {
    this.emcateProc.update_seqno_backward(emcateno);

    ra.addAttribute("word", word); // redirect로 데이터 전송
    ra.addAttribute("now_page", now_page); // redirect로 데이터 전송

    return "redirect:/emcate/list_search"; // @GetMapping(value="/list_search")
  }

  /**
   * 카테고리 공개 설정, http://localhost:9092/emcate/update_visible_y/1
   * 
   * @param model Controller -> Thymeleaf HTML로 데이터 전송에 사용
   * @return
   */
  @GetMapping(value = "/update_visible_y/{emcateno}")
  public String update_visible_y(HttpSession session, Model model, @PathVariable("emcateno") Integer emcateno,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page, RedirectAttributes ra) {
    
    if (this.memberProc.isMemberAdmin(session)) {
      this.emcateProc.update_visible_y(emcateno);

      ra.addAttribute("word", word); // redirect로 데이터 전송
      ra.addAttribute("now_page", now_page); // redirect로 데이터 전송

      return "redirect:/emcate/list_search"; // @GetMapping(value="/list_search")
    } else {
      return "redirect:/member/login_cookie_need";  // redirect
    }
  }

  /**
   * 카테고리 비공개 설정, http://localhost:9092/emcate/update_visible_n/1
   * 
   * @param model Controller -> Thymeleaf HTML로 데이터 전송에 사용
   * @return
   */
  @GetMapping(value = "/update_visible_n/{emcateno}")
  public String update_visible_n(HttpSession session, Model model, @PathVariable("emcateno") Integer emcateno,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "") int now_page, RedirectAttributes ra) {
    
    if (this.memberProc.isMemberAdmin(session)) {
      this.emcateProc.update_visible_n(emcateno);

      ra.addAttribute("word", word); // redirect로 데이터 전송
      ra.addAttribute("now_page", now_page); // redirect로 데이터 전송

      return "redirect:/emcate/list_search"; // @GetMapping(value="/list_search")
    } else {
      return "redirect:/member/login_cookie_need";  // redirect
    }
  }

//  /**
//   * 등록 폼 및 검색 목록
//   * http://localhost:9092/emcate/list_search
//   * http://localhost:9092/emcate/list_search?word=
//   * http://localhost:9092/emcate/list_search?word=까페
//   * @param model
//   * @return
//   */
//  @GetMapping(value="/list_search") 
//  public String list_search(Model model, 
//                                   @RequestParam(name="word", defaultValue = "") String word) {
//    EmcateVO emcateVO = new EmcateVO();
//    // emcateVO.setGenre("분류");
//    // emcateVO.setName("카테고리 이름을 입력하세요."); // Form으로 초기값을 전달
//    
//    // 카테고리 그룹 목록
//    ArrayList<String> list_genre = this.emcateProc.genreset();
//    emcateVO.setGenre(String.join("/", list_genre));
//    
//    model.addAttribute("emcateVO", emcateVO);
//    
//    word = Tool.checkNull(word);
//    
//    ArrayList<EmcateVO> list = this.emcateProc.list_search(word);
//    model.addAttribute("list", list);
//    
////    ArrayList<EmcateVO> menu = this.emcateProc.list_all_emcategrp_y();
////    model.addAttribute("menu", menu);
//
//    ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
//    model.addAttribute("menu", menu);
//    
//    int search_cnt = this.emcateProc.list_search_count(word);
//    model.addAttribute("search_cnt", search_cnt);    
//    
//    model.addAttribute("word", word);  
//    
//    return "/emcate/list_search";  // /templates/emcate/list_search.html
//  }
//  

  /**
   * 등록 폼 및 검색 목록 + 페이징 http://localhost:9092/emcate/list_search
   * http://localhost:9092/emcate/list_search?word=&now_page=
   * http://localhost:9092/emcate/list_search?word=까페&now_page=1
   * 
   * @param model
   * @return
   */
  @GetMapping(value = "/list_search")
  public String list_search_paging(HttpSession session, Model model,
      @RequestParam(name = "word", defaultValue = "") String word,
      @RequestParam(name = "now_page", defaultValue = "1") int now_page) {
    if (this.memberProc.isMemberAdmin(session)) {
      EmcateVO emcateVO = new EmcateVO();
      // emcateVO.setGenre("분류");
      // emcateVO.setName("카테고리 이름을 입력하세요."); // Form으로 초기값을 전달

      // 카테고리 그룹 목록
      ArrayList<String> list_genre = this.emcateProc.genreset();
      emcateVO.setGenre(String.join("/", list_genre));

      model.addAttribute("emcateVO", emcateVO);

      word = Tool.checkNull(word);

      ArrayList<EmcateVO> list = this.emcateProc.list_search_paging(word, now_page, this.record_per_page);
      model.addAttribute("list", list);

//      ArrayList<EmcateVO> menu = this.emcateProc.list_all_emcategrp_y();
//      model.addAttribute("menu", menu);
      
      for (EmcateVO emcate : list) {
        if (emcate.getName().equals("--")) {  // 대분류인 경우
            int totalCnt = 0;

            // 중분류 카테고리에서 대분류에 속하는 자료 수를 합산
            for (EmcateVO subEmcate : list) {
                if (!subEmcate.getName().equals("--") && subEmcate.getGenre().equals(emcate.getGenre())) {
                    totalCnt += this.emcateProc.cntcount(subEmcate.getEmcateno());
                    }
                } 
            emcate.setCnt(totalCnt); // 대분류 카테고리의 자료 수 설정
        } else {
            int emotionsCount = this.emcateProc.cntcount(emcate.getEmcateno()); // 각 중분류 카테고리의 자료 수 조회
            emcate.setCnt(emotionsCount); // EmcateVO 객체에 자료 수 설정
        }
      }

      ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
      model.addAttribute("menu", menu);

      int search_cnt = this.emcateProc.list_search_count(word);
      model.addAttribute("search_cnt", search_cnt);

      model.addAttribute("word", word); // 검색어

      // --------------------------------------------------------------------------------------
      // 페이지 번호 목록 생성
      // --------------------------------------------------------------------------------------
      int search_count = this.emcateProc.list_search_count(word);
      String paging = this.emcateProc.pagingBox(now_page, word, this.list_file_name, search_count, this.record_per_page,
          this.page_per_block);
      model.addAttribute("paging", paging);
      model.addAttribute("now_page", now_page);

      // 일련 변호 생성: 레코드 갯수 - ((현재 페이지수 -1) * 페이지당 레코드 수)
      int no = search_count - ((now_page - 1) * this.record_per_page);
      model.addAttribute("no", no);
      // --------------------------------------------------------------------------------------

      return "/emcate/list_search"; // /templates/emcate/list_search.html
    } else {
      return "redirect:/member/login_cookie_need"; // redirect
    }

  }

}
