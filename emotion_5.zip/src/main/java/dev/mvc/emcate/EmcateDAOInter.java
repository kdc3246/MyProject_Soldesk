package dev.mvc.emcate;

import java.util.ArrayList;
import java.util.Map;


public interface EmcateDAOInter {
  /**
   * <pre>
   * MyBATIS: insert id="create" parameterType="dev.mvc.emcate.EmcateVO"
   * insert: int를 리턴, 등록한 레코드 갯수를 리턴
   * id="create": 메소드명으로 사용
   * parameterType="dev.mvc.emcate.EmateVO": 메소드의 파라미터
   * Spring Boot가 자동으로 구현
   * </pre>
   * @param emcateVO
   * @return
   */
  public int create(EmcateVO emcateVO);
  
  /**
   * 전체 목록
   * SQL -> EmcateVO 객체 레코드 수 만큼 생성 -> ArrayList<emcateVO> 객체 생성되어 EmcateDAOInter로 리턴 
   * select id="list_all" resultType="dev.mvc.emcate.EmcateVO"
   * @return
   */
  public ArrayList<EmcateVO> list_all();  
  
  /**
   * 조회
   * @param emcateno
   * @return
   */
  public EmcateVO read(Integer emcateno);
  
  /**
   * 수정
   * @param emcateVO 수정할 내용
   * @return 수정된 레코드 갯수
   */
  public int update(EmcateVO emcateVO); 
  
  /**
   * 삭제
   * @param emcateno 삭제할 레코드 PK
   * @return 삭제된 레코드 갯수
   */
  public int delete(int emcateno);
  
  /*
   * 우선 순위 높임, 10 등 -> 1 등
   * @param emcateno
   * @return
   */
  public int update_seqno_forward(int emcateno);

  /*
   * 우선 순위 높임, 1 등 -> 10 등
   * @param emcateno
   * @return
   */
  public int update_seqno_backward(int emcateno);
  
  /**
   * 카테고리 공개 설정
   * @param emcateno
   * @return
   */
  public int update_visible_y(int emcateno);
  
  /**
   * 카테고리 비공개 설정
   * @param emcateno
   * @return
   */
  public int update_visible_n(int emcateno);
  
  /**
   * 숨긴 '카테고리 그룹'을 제외하고 접속자에게 공개할 '카테고리 그룹' 출력
   * SQL -> EmcateVO 객체 레코드 수 만큼 생성 -> ArrayList<emcateVO> 객체 생성되어 EmcateDAOInter로 리턴 
   * select id="list_all_emcategrp_y" resultType="dev.mvc.emcate.EmcateVO"
   * @return
   */
  public ArrayList<EmcateVO> list_all_emcategrp_y();
  
  /**
   * 숨긴 '카테고리 그룹'을 제외하고 접속자에게 공개할 '카테고리 그룹' 출력
   * SQL -> EmcateVO 객체 레코드 수 만큼 생성 -> ArrayList<emcateVO> 객체 생성되어 EmcateDAOInter로 리턴 
   * select id="list_all_emcate_y" resultType="dev.mvc.emcate.EmcateVO"
   * @return
   */
  public ArrayList<EmcateVO> list_all_emcate_y(String genre);
  
  /**
   * 장르 목록
   * @return
   */
  public ArrayList<String> genreset();
  
  /**
   * 검색 목록
   * SQL -> EmcateVO 객체 레코드 수 만큼 생성 -> ArrayList<emcateVO> 객체 생성되어 EmcateDAOInter로 리턴 
   * select id="list_search" resultType="dev.mvc.emcate.EmcateVO" parameterType="String"
   * @return
   */
  public ArrayList<EmcateVO> list_search(String word);
  
  /**
   * 검색 갯수
   * @param word
   * @return
   */
  public Integer list_search_count(String word);
  
  /**
   * 검색 + 페이징
   * select id="list_search_paging" resultType="dev.mvc.emcate.EmcateVO" parameterType="Map"
   * @return
   */
  public ArrayList<EmcateVO> list_search_paging(Map<String, Object> map);
  
  /**
   * 전체 자료 수 산출
   * SQL -> 전체 cate 테이블의 자료 수를 반환
   * select id="cntcount" resultType="Integer"
   * @return 전체 자료 수
   */
  public Integer cntcount(int cntcount);
}


