//package dev.mvc.emcate;
//
//import java.util.ArrayList;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//// 알고리즘 구현
////@Service("dev.mvc.emcate.EmcateProc2022")
//public class EmcateProc2022 implements EmcateProcInter {
//  @Autowired // EncateDAOInter를 구현한 클래스의 객체를 자동으로 생성하여 emcateDAO 객체에 할당
//  private EmcateDAOInter emcateDAO;
//  
//  public EmcateProc2022() {
//    System.out.println("-> EmcateProc2022 created.");
//  }
//  
//  @Override
//  public int create(EmcateVO emcateVO) {
//    int cnt = this.emcateDAO.create(emcateVO);
//    
//    return cnt;
//  }
//
//  @Override
//  public ArrayList<EmcateVO> list_all() {
//    ArrayList<EmcateVO> list = this.emcateDAO.list_all();
//    
//    return list;
//  }
//
//  @Override
//  public EmcateVO read(Integer emcateno) {
//    EmcateVO emcateVO = this.emcateDAO.read(emcateno);
//    
//    return emcateVO;
//  }
//
//  @Override
//  public int update(EmcateVO emcateVO) {
//    int cnt = this.emcateDAO.update(emcateVO);
//    
//    return cnt;
//  }
//
//  @Override
//  public int delete(int emcateno) {
//    int cnt = this.emcateDAO.delete(emcateno);
//    return cnt;
//  }
//
//  @Override
//  public int update_seqno_forward(int emcateno) {
//    int cnt = this.emcateDAO.update_seqno_forward(emcateno);
//    return cnt;
//  }
//  
//  @Override
//  public int update_seqno_backward(int emcateno) {
//    int cnt = this.emcateDAO.update_seqno_backward(emcateno);
//    return cnt;
//  }
//  
//  @Override
//  public int update_visible_y(int emcateno) {
//    int cnt = this.emcateDAO.update_visible_y(emcateno);
//    return cnt;
//  }
//
//  @Override
//  public int update_visible_n(int emcateno) {
//    int cnt = this.emcateDAO.update_visible_n(emcateno);
//    return cnt;
//  }
//  
//  @Override
//  public ArrayList<EmcateVO> list_all_emcategrp_y() {
//    ArrayList<EmcateVO> list = this.emcateDAO.list_all_emcategrp_y();
//    
//    return list;
//  }
//  
//  @Override
//  public ArrayList<EmcateVO> list_all_emcate_y(String genre) {
//    ArrayList<EmcateVO> list = this.emcateDAO.list_all_emcate_y(genre);
//    
//    return list;
//  }
//
//  @Override
//  public ArrayList<EmcateVOMenu> menu() {
//    // TODO Auto-generated method stub
//    return null;
//  }
//
//  @Override
//  public ArrayList<String> genreset() {
//    // TODO Auto-generated method stub
//    return null;
//  }
//
//  @Override
//  public ArrayList<EmcateVO> list_search(String word) {
//    // TODO Auto-generated method stub
//    return null;
//  }
//
//  @Override
//  public Integer list_search_count(String word) {
//    // TODO Auto-generated method stub
//    return null;
//  }
//
//  @Override
//  public ArrayList<EmcateVO> list_search_paging(String word, int now_page, int record_per_page) {
//    // TODO Auto-generated method stub
//    return null;
//  }
//
//  @Override
//  public String pagingBox(int now_page, String word, String list_file_name, int search_count, int record_per_page,
//      int page_per_block) {
//    // TODO Auto-generated method stub
//    return null;
//  }
//
//}
//
//
//
//
