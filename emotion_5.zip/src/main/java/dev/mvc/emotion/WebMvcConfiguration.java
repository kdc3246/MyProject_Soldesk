package dev.mvc.emotion;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import dev.mvc.emotions.Emotions;
import dev.mvc.tool.Tool;

@Configuration
public class WebMvcConfiguration implements WebMvcConfigurer{
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Windows: path = "C:/kd/deploy/myresort/emotions/storage";
        // ▶ file:///C:/kd/deploy/myresort/emotions/storage
      
        // Ubuntu: path = "/home/ubuntu/deploy/myresort/emotions/storage";
        // ▶ file:////home/ubuntu/deploy/myresort/emotions/storage
      
        // C:/kd/deploy/myresort/emotions/storage ->  /emotions/storage -> http://localhost:9092/emotions/storage;
        registry.addResourceHandler("/emotions/storage/**").addResourceLocations("file:///" +  Emotions.getUploadDir());

        // C:/kd/deploy/myresort/food/storage ->  /food/storage -> http://localhost:9092/food/storage;
        // registry.addResourceHandler("/food/storage/**").addResourceLocations("file:///" +  Food.getUploadDir());

        // C:/kd/deploy/myresort/trip/storage ->  /trip/storage -> http://localhost:9092/trip/storage;
        // registry.addResourceHandler("/trip/storage/**").addResourceLocations("file:///" +  Trip.getUploadDir());
        
    }
 
}


