package dev.mvc.emotion;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import dev.mvc.emcate.EmcateProcInter;
import dev.mvc.emcate.EmcateVO;
import dev.mvc.emcate.EmcateVOMenu;
import dev.mvc.tool.Security;

@Controller
public class HomeCont {
  @Autowired
  @Qualifier("dev.mvc.emcate.EmcateProc")
  private EmcateProcInter emcateProc; // EmcateProc class 객체가 생성되어 할당
  
  @Autowired
  private Security security;
  
  public HomeCont() {
    System.out.println("-> HomeCnont created.");
  }
  
  // http://localhost:9092
  // http://localhost:9092/index.do
  @GetMapping(value={"/", "/index.do"}) 
  public String home(Model model) {
//    ArrayList<EmcateVO> menu = this.emcateProc.list_all_emcategrp_y();
//    model.addAttribute("menu", menu);
    
    ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
    model.addAttribute("menu", menu);
    
    return "index";  // /templates/index.html
  }
  
}
