/**********************************/
/* Table Name: 카테고리 */
/**********************************/
-- 장르를 카테고리 그룹 테이블로 처리하지 않고 컬럼으로 처리함 ★
DROP TABLE emcate;

CREATE TABLE emcate(
    EMCATENO                            NUMBER(10)     NOT NULL     PRIMARY KEY,
    GENRE                               VARCHAR2(20)  NOT NULL,  
    NAME                                VARCHAR2(30)  NOT NULL,
    CNT                                 NUMBER(7)     DEFAULT 0     NOT NULL,
    SEQNO                               NUMBER(5)     DEFAULT 1     NOT NULL,
    VISIBLE                             CHAR(1)      DEFAULT 'N'    NOT NULL,
    RDATE                               DATE          NOT NULL
);

COMMENT ON TABLE emcate is '감정';
COMMENT ON COLUMN emcate.CATENO is '감정 번호';
COMMENT ON COLUMN emcate.GENRE is '장르';
COMMENT ON COLUMN emcate.NAME is '감정 이름';
COMMENT ON COLUMN emcate.CNT is '관련 자료수';
COMMENT ON COLUMN emcate.SEQNO is '출력 순서';
COMMENT ON COLUMN emcate.VISIBLE is '출력 모드';
COMMENT ON COLUMN emcate.RDATE is '등록일';

DROP SEQUENCE EMCATE_SEQ;

CREATE SEQUENCE EMCATE_SEQ
START WITH 1         -- 시작 번호
INCREMENT BY 1       -- 증가값
MAXVALUE 9999999999  -- 최대값: 9999999999 --> NUMBER(10) 대응
CACHE 2              -- 2번은 메모리에서만 계산
NOCYCLE;             -- 다시 1부터 생성되는 것을 방지
       
-- CRUD
-- 등록
INSERT INTO emcate(emcateno, genre, name, cnt, seqno, visible, rdate) 
VALUES(emcate_seq.nextval, '슬픔', '하염없이 눈물이나', 0, 0, 'Y', sysdate);

INSERT INTO emcate(emcateno, genre, name, cnt, seqno, visible, rdate) 
VALUES(emcate_seq.nextval, '기쁨', '행복한 사람', 0, 0, 'Y', sysdate);

INSERT INTO emcate(emcateno, genre, name, cnt, seqno, visible, rdate) 
VALUES(emcate_seq.nextval, '예민함', '난 이런게 싫어!', 0, 0, 'Y', sysdate);

commit;

-- 목록
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate ORDER BY emcateno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
         1 슬픔                 하염없이 눈물이나                       0          0 Y 2024-09-11 12:27:48
         2 기쁨                 행복한 사람                             0          0 Y 2024-09-11 12:27:48
         3 예민함               난 이런게 싫어!                         0          0 Y 2024-09-11 12:27:48

-- 조회
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate WHERE emcateno=1;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
         1 슬픔                 하염없이 눈물이나                       0          0 Y 2024-09-11 12:27:48

-- 수정
UPDATE emcate SET genre='화남', name = '어떤놈이야!', cnt=10, seqno=20, visible='Y', rdate=sysdate WHERE emcateno=1; 

commit;

SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate WHERE emcateno=1;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
         1 화남                 어떤놈이야!                            10         20 Y 2024-09-11 12:28:19

SELECT * FROM emcate;

-- 삭제
DELETE FROM emcate WHERE emcateno=49;
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate ORDER BY emcateno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
         1 화남                 어떤놈이야!                            10         20 Y 2024-09-11 12:28:19
         2 기쁨                 행복한 사람                             0          0 Y 2024-09-11 12:27:48

-- -----------------------------------------------------------------------------
-- emotion_v3
-- -----------------------------------------------------------------------------
DELETE FROM emcate;
COMMIT;

-- 데이터 준비
INSERT INTO emcate(emcateno, genre, name, cnt, seqno, visible, rdate) 
VALUES(emcate_seq.nextval, '절망', '--', 0, 0, 'Y', sysdate);

INSERT INTO emcate(emcateno, genre, name, cnt, seqno, visible, rdate) 
VALUES(emcate_seq.nextval, '행복', '--', 0, 0, 'Y', sysdate);

INSERT INTO emcate(emcateno, genre, name, cnt, seqno, visible, rdate) 
VALUES(emcate_seq.nextval, '화남', '--', 0, 0, 'Y', sysdate);

-- 목록 변경됨
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate ORDER BY emcateno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        21 절망                 --                                      0          0 Y 2024-09-13 10:08:04
        22 행복                 --                                      0          0 Y 2024-09-13 10:08:04
        23 화남                 --                                      0          0 Y 2024-09-13 10:08:04

-- 출력 우선순위 낮춤
UPDATE emcate SET seqno=seqno+1 WHERE emcateno=21;
UPDATE emcate SET seqno=seqno+1 WHERE emcateno=23;
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate ORDER BY seqno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        22 행복                 --                                      0          0 Y 2024-09-13 10:08:04
        21 절망                 --                                      0          1 Y 2024-09-13 10:08:04
        23 화남                 --                                      0          1 Y 2024-09-13 10:08:04

UPDATE emcate SET seqno=seqno+1 WHERE emcateno=23;
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate ORDER BY seqno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        22 행복                 --                                      0          0 Y 2024-09-13 10:08:04
        21 절망                 --                                      0          1 Y 2024-09-13 10:08:04
        23 화남                 --                                      0          2 Y 2024-09-13 10:08:04

-- 테스트를 위하여 우선순위 2단계 낮춤
UPDATE emcate SET seqno=seqno+2;
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate ORDER BY seqno ASC;
  EMCATENO GENRE    NAME      CNT      SEQNO   V     RDATE              
---------- -------- --------- -------- ------  ----- -------------------
        22 행복      --        0        2       Y     2024-09-13 10:08:04
        21 절망      --        0        3       Y     2024-09-13 10:08:04
        23 화남      --        0        4       Y     2024-09-13 10:08:04


-- 출력 우선순위 높임
UPDATE emcate SET seqno = seqno-1 WHERE emcateno=23;
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate ORDER BY seqno ASC;
  EMCATENO GENRE     NAME        CNT    SEQNO   V       RDATE              
---------- --------- ----------- -----  ------- ------  -------------------
        22 행복       --          0      1       Y       2024-09-13 10:08:04
        21 절망       --          0      2       Y       2024-09-13 10:08:04
        23 화남       --          0      3       Y       2024-09-13 10:08:04


-- 카테고리 공개 설정
UPDATE emcate SET visible='Y' WHERE emcateno=1;

-- 카테고리 비공개 설정 
UPDATE emcate SET visible='N' WHERE emcateno=1;

COMMIT;

-- -----------------------------------------------------------------------------
-- 회원/비회원에게 공개할 카테고리 그룹(대분류) 목록
-- -----------------------------------------------------------------------------
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate ORDER BY seqno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        21 절망                 --                                      0          1 Y 2024-09-13 10:08:04
        23 화남                 --                                      0          2 Y 2024-09-13 10:08:04
        24 소심                 잘 모르겠숴..                           0          3 Y 2024-09-13 01:16:53
        22 행복                 --                                      0          4 Y 2024-09-13 10:08:04
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate WHERE name='--' ORDER BY seqno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        21 절망                 --                                      0          1 Y 2024-09-13 10:08:04
        23 화남                 --                                      0          2 Y 2024-09-13 10:08:04
        22 행복                 --                                      0          4 Y 2024-09-13 10:08:04
-- 숨긴 '카테고리 그룹'을 제외하고 접속자에게 공개할 '카테고리 그룹' 출력
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate WHERE name='--' AND visible='Y' ORDER BY seqno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        21 절망                 --                                      0          1 Y 2024-09-13 10:08:04
        22 행복                 --                                      0          4 Y 2024-09-13 10:08:04

-- -----------------------------------------------------------------------------
-- 회원/비회원에게 공개할 카테고리(중분류) 목록
-- -----------------------------------------------------------------------------
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate WHERE genre='화남' ORDER BY seqno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        23 화남                 --                                      0          2 N 2024-09-13 10:08:04
        25 화남                 매우 화가난다!!                         0          5 Y 2024-09-19 10:58:19
        26 화남                 ㅋㅎㅋㅎㅋ미치겠눼                      0          7 Y 2024-09-19 10:58:32
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate WHERE name!='--' AND visible='Y' AND genre='화남' ORDER BY seqno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        25 화남                 매우 화가난다!!                         0          5 Y 2024-09-19 10:58:19
        26 화남                 ㅋㅎㅋㅎㅋ미치겠눼                      0          7 Y 2024-09-19 10:58:32
SELECT emcateno, genre, name, cnt, seqno, visible, rdate FROM emcate WHERE name!='--' AND visible='Y' AND genre='행복' ORDER BY seqno ASC;
  EMCATENO GENRE                NAME                                  CNT      SEQNO V RDATE              
---------- -------------------- ------------------------------ ---------- ---------- - -------------------
        27 행복                 난 오늘도 행복햐~~~♥                   0          8 Y 2024-09-19 11:00:30