// 이미지가 사라지고 텍스트가 나타나는 기능
window.onload = function() {
    setTimeout(function() {
        // 이미지 숨기기
        document.getElementById('emotionGif').style.display = 'none';
        // 텍스트 표시하기
        document.getElementById('textLabel') .style.display = 'block';
    }, 11000); // 11초 후에 실행
}