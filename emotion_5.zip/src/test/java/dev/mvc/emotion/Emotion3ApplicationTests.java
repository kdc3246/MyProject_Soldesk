package dev.mvc.emotion;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import dev.mvc.emcate.EmcateDAOInter;
import dev.mvc.emcate.EmcateProcInter;
import dev.mvc.emcate.EmcateVO;
import dev.mvc.emcate.EmcateVOMenu;

@SpringBootTest
class Emotion3ApplicationTests {
  @Autowired  // CateDAOInter를 구현한 클래스의 객체를 자동으로 생성하여 cateDAO 객체에 할당
  private EmcateDAOInter emcateDAO;
  
  @Autowired
  @Qualifier("dev.mvc.emcate.EmcateProc")
  private EmcateProcInter  emcateProc;

	@Test
	void contextLoads() {
	}
	
//	@Test
//	public void msg() {
//	  System.out.println("-> msg");
//	}
	
//	@Test
//  public void menu() {
//    ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
//    
//    for (EmcateVOMenu emcateVOMenu: menu) {
//      System.out.println("-> genre: " + emcateVOMenu.getGenre());
//      
//      ArrayList<EmcateVO> list_name = emcateVOMenu.getList_name();
//      for (EmcateVO emcateVO:list_name) {
//        System.out.println("    " + emcateVO.getName());
//      }
//      
//    }
//  }
	
//	@Test
//public void testCreate() {
//  EmcateVO emcateVO = new EmcateVO();
//  emcateVO.setName("기쁨");
//  emcateVO.setSeqno(1);
//  emcateVO.setVisible("Y");
//  int cnt = thisemcateDAO.create(emcateVO);
//  System.out.println("cnt: " + cnt);
//}

//@Test
//public void testCreate() {
//  EmcateVO emcateVO = new EmcateVO();
//  emcateVO.setName("화남");
//  emcateVO.setSeqno(1);
//  emcateVO.setVisible("Y");
//  
//  int cnt = this.emcateProc.create(emcateVO);
//  System.out.println("cnt: " + cnt);
//
//}

//@Test
//public void list_all() {
//  ArrayList<EmcateVO> list = this.emcateProc.list_all();
//  
//  for (EmcateVO emcateVO:list) {
//    System.out.println(emcateVO.toString());
//  }
//}

//@Test
//public void read() {
//  EmcateVO emcateVO = this.emcateProc.read(1);
//  System.out.println(emcateVO.toString());
//}

//@Test
//public void menu() {
//  ArrayList<EmcateVOMenu> menu = this.emcateProc.menu();
//  
//  for (EmcateVOMenu emcateVOMenu: menu) {
//    System.out.println("-> genre: " + emcateVOMenu.getGenre());
//    
//    ArrayList<EmcateVO> list_name = emcateVOMenu.getList_name();
//    for (EmcateVO emcateVO: list_name) {
//      System.out.println("    " + emcateVO.getName());
//    }
//    
//  }
//}

//@Test
//public void genreset() {
//  ArrayList<String> list= this.emcateProc.genreset();
//  for(String genre:list) {
//    System.out.println(genre);
//    
//  }
//  
//  System.out.println(String.join("/", list));
//  
//}

//@Test
//public void Hangul() {
////  String word = URLEncoder.encode("오버렌딩");
////  System.out.println("원본: %EC%98%A4%EB%B2%84%EB%A0%8C%EB%94%A9");
////  System.out.println("변환: " + word);
////  
////  word = URLDecoder.decode("%EC%98%A4%EB%B2%84%EB%A0%8C%EB%94%A9"); 
////  System.out.println("복원: " + word);
//
//  // JDK 10+, VSCode 사용
//  String word = URLEncoder.encode("오버렌딩", StandardCharsets.UTF_8);  // 한굴 -> 16진수 코드화
//  System.out.println("원본: %EC%98%A4%EB%B2%84%EB%A0%8C%EB%94%A9");
//  System.out.println("변환: " + word);
//  
//  // 16진수 -> 한글
//  word = URLDecoder.decode("%EC%98%A4%EB%B2%84%EB%A0%8C%EB%94%A9", StandardCharsets.UTF_8); 
//  System.out.println("복원: " + word);
//}
	
  @Test
  public void list_search_paging() {
    this.emcateProc.list_search_paging("기쁨", 1, 3);
    this.emcateProc.list_search_paging("까칠", 1, 3);
    this.emcateProc.list_search_paging("화남", 1, 3);
    this.emcateProc.list_search_paging("슬픔", 1, 3);
    this.emcateProc.list_search_paging("소심", 1, 3);
//        WHERE r >= 1 AND r <= 3
//        -> 3
//        WHERE r >= 1 AND r <= 3
//        -> 3
//        WHERE r >= 1 AND r <= 3
//        -> 3
//        WHERE r >= 1 AND r <= 3
//        -> 3
//        WHERE r >= 1 AND r <= 3
//        -> 3
  }

}
