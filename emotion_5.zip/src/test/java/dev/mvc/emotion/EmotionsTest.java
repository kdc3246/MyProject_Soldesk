package dev.mvc.emotion;

import java.util.HashMap;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import dev.mvc.emcate.EmcateProcInter;
import dev.mvc.emotions.EmotionsProcInter;
import dev.mvc.member.MemberProcInter;

@SpringBootTest
public class EmotionsTest {
  @Autowired
  @Qualifier("dev.mvc.member.MemberProc") // "dev.mvc.admin.AdminProc"라고 명명된 클래스
  private MemberProcInter memberProc; // AdminProcInter를 구현한 AdminProc 클래스의 객체를 자동으로 생성하여 할당

  @Autowired
  @Qualifier("dev.mvc.emotions.EmotionsProc")  // @Component("dev.mvc.emotions.EmotionsProc")
  private EmotionsProcInter emotionsProc;
  
  @Test
  public void testRead() {
    HashMap<String, Object> hashMap = new HashMap<String, Object>();
    hashMap.put("emotionsno", 3); // 자신이 가지고있는 번호와 패스워드 넣기
    // hashMap.put("passwd", "fS/kjO+fuEKk06Zl7VYMhg==");
    hashMap.put("passwd", "1234");
    
    System.out.println("-> cnt: " + this.emotionsProc.password_check(hashMap));
    
  }
}